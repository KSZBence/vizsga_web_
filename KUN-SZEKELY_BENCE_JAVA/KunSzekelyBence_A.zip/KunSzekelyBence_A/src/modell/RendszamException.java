/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modell;

/**
 *
 * @author install
 */
public class RendszamException extends IllegalArgumentException{

    public RendszamException(String s) {
        super(s);
    }
    
}
