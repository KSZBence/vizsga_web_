/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modell;

/**
 *
 * @author install
 */
public class Hajo extends Jarmu{
    private int ferohely;
    private String nev;

    public Hajo(String rendzsam, minosites min, int ferohely, String nev) {
        super(rendzsam, min);
        this.ferohely = ferohely;
        this.nev = nev;
    }

    

   
    
}
